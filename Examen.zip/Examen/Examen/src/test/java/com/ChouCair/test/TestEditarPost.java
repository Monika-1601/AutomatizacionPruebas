package com.ChouCair.test;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.runners.MethodSorters;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestEditarPost {

	private static WebDriver driver;
	private String URLPaginaInicio="https://s1.demo.opensourcecms.com/wordpress/wp-login.php";
	
	@BeforeClass
	public static void ConfigurarDriver(){
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		
	}
	
	@AfterClass
	public static void CerrarDriver(){
		//driver.quit();
	}	
	
	@Test
	public void TestBuscarPostporTitulo() {
		
	try{	
		//WebDriverManager.chromedriver().setup();			
		//WebDriver driver = new ChromeDriver();		
		driver.get(URLPaginaInicio);
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		 
		WebElement txtUserName=driver.findElement(By.id("user_login"));
		txtUserName.sendKeys("opensourcecms");
		txtUserName.sendKeys(Keys.TAB);
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		 
		WebElement txtPassword=driver.findElement(By.id("user_pass"));
		txtPassword.sendKeys("opensourcecms");
		txtPassword.sendKeys(Keys.TAB);
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.findElement(By.id("wp-submit")).click();		
		
		driver.findElement(By.xpath("//*[@id=\"menu-posts\"]/a/div[2]")).click();
	
		driver.findElement(By.xpath("//*[@id=\"menu-posts\"]/ul/li[2]/a")).click();
						
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		WebElement tblPost=driver.findElement(By.xpath("//*[@id=\"posts-filter\"]/table"));
		
		List <WebElement>  registros= tblPost.findElements(By.tagName("tr"));
		
		WebElement primerregistro=registros.get(1);
					
		primerregistro.click();
		
		driver.findElement(By.linkText("Edit")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebElement txtPostTitle=driver.findElement(By.id("post-title-0"));
		txtPostTitle.sendKeys(Keys.CONTROL + "a");
		txtPostTitle.sendKeys(Keys.DELETE);
		
		txtPostTitle.sendKeys("Post Modificado");
				
		driver.findElement(By.xpath("//*[@id=\"editor\"]/div/div/div/div[1]/div[2]/button[2]")).click();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//driver.findElement(By.xpath("//*[@id=\"editor\"]/div/div/div/div[3]/div/div/div[1]/div/button")).click();
		
		
		
		// driver.quit();
		 
	}catch(Exception e)
	
	{
		e.printStackTrace();
		//System.out.println(e.getMessage());
		Assert.fail();
		
	}
}
	
	
}
