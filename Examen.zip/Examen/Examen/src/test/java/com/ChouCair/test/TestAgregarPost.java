package com.ChouCair.test;
import java.util.concurrent.TimeUnit;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.runners.MethodSorters;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestAgregarPost {

	private static WebDriver driver;
	private String URLPaginaInicio="https://s1.demo.opensourcecms.com/wordpress/wp-login.php";

	
	@BeforeClass
	public static void ConfigurarDriver(){
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		
	}
	
	@AfterClass
	public static void CerrarDriver(){
		//driver.quit();
	}	
	
	
	@Test	
	public void a_TestAgregarPost() {
		
		
		
	try{	
		driver.get(URLPaginaInicio);
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		 
		WebElement txtUserName=driver.findElement(By.id("user_login"));
		txtUserName.sendKeys("opensourcecms");
		txtUserName.sendKeys(Keys.TAB);
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		 
		WebElement txtPassword=driver.findElement(By.id("user_pass"));
		txtPassword.sendKeys("opensourcecms");
		txtPassword.sendKeys(Keys.TAB);
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.findElement(By.id("wp-submit")).click();
		
		
		driver.findElement(By.xpath("//*[@id=\"menu-posts\"]/a/div[2]")).click();
	
		driver.findElement(By.linkText("Add New")).click();			
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		WebElement txtPostTitle=driver.findElement(By.id("post-title-0"));
		txtPostTitle.sendKeys("Aumenta la venta de bicicletas previo a la Navidad.");
		
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        		
		
		driver.findElement(By.xpath("//*[@id=\"editor\"]/div/div/div/div[1]/div[2]/button")).click();
		
				
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		 
	}catch(Exception e)
	
	{
		e.printStackTrace();
		System.out.println(e.getMessage());
		Assert.fail();
		
	}
}

	
}
