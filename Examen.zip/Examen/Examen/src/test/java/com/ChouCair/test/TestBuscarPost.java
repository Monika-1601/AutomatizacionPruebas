package com.ChouCair.test;

import java.util.concurrent.TimeUnit;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.runners.MethodSorters;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestBuscarPost {
	
	private static WebDriver driver;
	private String URLPaginaInicio="https://s1.demo.opensourcecms.com/wordpress/wp-login.php";
	
	@BeforeClass
	public static void ConfigurarDriver(){
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		
	}
	
	@AfterClass
	public static void CerrarDriver(){
		//driver.quit();
	}	
	

	@Test
	public void TestBuscarPostporTitulo() {
		
	try{	
		//WebDriverManager.chromedriver().setup();			
		//WebDriver driver = new ChromeDriver();		
		driver.get(URLPaginaInicio);
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		 
		WebElement txtUserName=driver.findElement(By.id("user_login"));
		txtUserName.sendKeys("opensourcecms");
		txtUserName.sendKeys(Keys.TAB);
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		 
		WebElement txtPassword=driver.findElement(By.id("user_pass"));
		txtPassword.sendKeys("opensourcecms");
		txtPassword.sendKeys(Keys.TAB);
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.findElement(By.id("wp-submit")).click();
		
		
		driver.findElement(By.xpath("//*[@id=\"menu-posts\"]/a/div[2]")).click();
	
		
		driver.findElement(By.xpath("//*[@id=\"menu-posts\"]/ul/li[2]/a")).click();
		
		
		driver.findElement(By.name("s")).sendKeys("Hello world!");
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("search-submit")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		
		// driver.quit();
		 
	}catch(Exception e)
	
	{
		e.printStackTrace();
		//System.out.println(e.getMessage());
		Assert.fail();
		
	}
}
	
	
	
	
}
